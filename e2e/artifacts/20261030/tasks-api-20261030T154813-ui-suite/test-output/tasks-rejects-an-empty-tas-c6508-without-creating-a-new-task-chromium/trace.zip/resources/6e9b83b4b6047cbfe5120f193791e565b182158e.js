import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=302deb8a";
var _jsxFileName = "C:/Adrian/Work/TestProjects/github/PlayWright_Agentic/frontend/src/App.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=302deb8a";
var _s = $RefreshSig$();
const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:5000/api/tasks";
function App() {
	_s();
	const [tasks, setTasks] = useState([]);
	const [title, setTitle] = useState("");
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(true);
	const [apiAvailable, setApiAvailable] = useState(true);
	async function loadTasks() {
		const response = await fetch(API_URL);
		if (!response.ok) throw new Error("Could not load tasks.");
		const data = await response.json();
		setTasks(data);
		setApiAvailable(true);
		setError("");
	}
	useEffect(() => {
		loadTasks().catch(() => {
			setApiAvailable(false);
			setError("Cannot connect to the API. Start the .NET backend and try again.");
		}).finally(() => setLoading(false));
	}, []);
	async function addTask(event) {
		event.preventDefault();
		const cleanTitle = title.trim();
		if (!cleanTitle) {
			setError("Title is required.");
			return;
		}
		try {
			const response = await fetch(API_URL, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ title: cleanTitle })
			});
			if (!response.ok) {
				const body = await response.json().catch(() => null);
				throw new Error(body?.error ?? "Could not create task.");
			}
			setTitle("");
			await loadTasks();
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Could not create task.");
		}
	}
	async function completeTask(id) {
		try {
			const response = await fetch(`${API_URL}/${id}/complete`, { method: "PUT" });
			if (!response.ok) throw new Error("Could not complete task.");
			await loadTasks();
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Could not complete task.");
		}
	}
	const completedCount = tasks.filter((task) => task.isCompleted).length;
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "app-shell",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "topbar",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "brand-mark",
						"aria-hidden": "true",
						children: "✓"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "eyebrow",
						children: "YOUR WORKSPACE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("h1", { children: "Task Manager" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: `connection ${apiAvailable ? "online" : "offline"}`,
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "status-dot" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 11
						}, this), apiAvailable ? "API connected" : "API unavailable"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "welcome",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "eyebrow",
						children: "MAKE TODAY COUNT"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", { children: "One thing at a time." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "welcome-copy",
						children: "Capture your next step and keep your momentum going."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "task-panel",
				"aria-labelledby": "tasks-heading",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "panel-heading",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							id: "tasks-heading",
							children: "Your tasks"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "muted",
							children: [
								tasks.length,
								" total · ",
								completedCount,
								" completed"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "count-pill",
							children: [tasks.length - completedCount, " left"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						className: "task-form",
						onSubmit: addTask,
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "sr-only",
								htmlFor: "task-title",
								children: "Task title"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								id: "task-title",
								value: title,
								onChange: (event) => setTitle(event.target.value),
								placeholder: "What needs to be done?",
								autoComplete: "off"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "add-button",
								children: "+ Add task"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 9
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						className: "error-message",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 19
					}, this),
					loading ? /* @__PURE__ */ _jsxDEV("p", {
						className: "empty-state",
						children: "Loading your tasks…"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 11
					}, this) : tasks.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "empty-state",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "empty-icon",
							"aria-hidden": "true",
							children: "✦"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: "No tasks yet. Add one above to get started." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("ul", {
						className: "task-list",
						"aria-label": "Tasks",
						children: tasks.map((task) => /* @__PURE__ */ _jsxDEV("li", {
							className: `task-item ${task.isCompleted ? "is-completed" : ""}`,
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "task-status",
									"aria-hidden": "true",
									children: task.isCompleted ? "✓" : ""
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "task-title",
									children: task.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 17
								}, this),
								task.isCompleted ? /* @__PURE__ */ _jsxDEV("span", {
									className: "completed-label",
									children: "Completed"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "complete-button",
									onClick: () => completeTask(task.id),
									"aria-label": `Complete ${task.title}`,
									children: "Complete"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 19
								}, this)
							]
						}, task.id, true, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "footer",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: "Built for focus." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 153,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "React · TypeScript · .NET API" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 152,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 77,
		columnNumber: 5
	}, this);
}
_s(App, "xP8BGxTXs+StPXE09DfQ098fzIU=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Adrian/Work/TestProjects/github/PlayWright_Agentic/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Adrian/Work/TestProjects/github/PlayWright_Agentic/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Adrian/Work/TestProjects/github/PlayWright_Agentic/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQzs7OztBQVFwRCxNQUFNLFVBQVUsWUFBWSxJQUFJLGdCQUFnQjtBQUVoRCxTQUFTLE1BQU07O0NBQ2IsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFpQixDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsSUFBSTtDQUVyRCxlQUFlLFlBQVk7RUFDekIsTUFBTSxXQUFXLE1BQU0sTUFBTSxPQUFPO0VBQ3BDLElBQUksQ0FBQyxTQUFTLElBQUksTUFBTSxJQUFJLE1BQU0sdUJBQXVCO0VBQ3pELE1BQU0sT0FBUSxNQUFNLFNBQVMsS0FBSztFQUNsQyxTQUFTLElBQUk7RUFDYixnQkFBZ0IsSUFBSTtFQUNwQixTQUFTLEVBQUU7Q0FDYjtDQUVBLGdCQUFnQjtFQUNkLFVBQVUsQ0FBQyxDQUNSLFlBQVk7R0FDWCxnQkFBZ0IsS0FBSztHQUNyQixTQUFTLGtFQUFrRTtFQUM3RSxDQUFDLENBQUMsQ0FDRCxjQUFjLFdBQVcsS0FBSyxDQUFDO0NBQ3BDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsZUFBZSxRQUFRLE9BQW1DO0VBQ3hELE1BQU0sZUFBZTtFQUNyQixNQUFNLGFBQWEsTUFBTSxLQUFLO0VBRTlCLElBQUksQ0FBQyxZQUFZO0dBQ2YsU0FBUyxvQkFBb0I7R0FDN0I7RUFDRjtFQUVBLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUFNLFNBQVM7SUFDcEMsUUFBUTtJQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQzlDLE1BQU0sS0FBSyxVQUFVLEVBQUUsT0FBTyxXQUFXLENBQUM7R0FDNUMsQ0FBQztHQUVELElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxZQUFZLElBQUk7SUFDbkQsTUFBTSxJQUFJLE1BQU0sTUFBTSxTQUFTLHdCQUF3QjtHQUN6RDtHQUVBLFNBQVMsRUFBRTtHQUNYLE1BQU0sVUFBVTtFQUNsQixTQUFTLFFBQVE7R0FDZixTQUFTLGtCQUFrQixRQUFRLE9BQU8sVUFBVSx3QkFBd0I7RUFDOUU7Q0FDRjtDQUVBLGVBQWUsYUFBYSxJQUFZO0VBQ3RDLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsUUFBUSxHQUFHLEdBQUcsWUFBWSxFQUFFLFFBQVEsTUFBTSxDQUFDO0dBQzNFLElBQUksQ0FBQyxTQUFTLElBQUksTUFBTSxJQUFJLE1BQU0sMEJBQTBCO0dBQzVELE1BQU0sVUFBVTtFQUNsQixTQUFTLFFBQVE7R0FDZixTQUFTLGtCQUFrQixRQUFRLE9BQU8sVUFBVSwwQkFBMEI7RUFDaEY7Q0FDRjtDQUVBLE1BQU0saUJBQWlCLE1BQU0sUUFBUSxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUM7Q0FFaEUsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUNFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBYSxlQUFZO2dCQUFPO0tBQU07Ozs7O0tBQ3JELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBVTtLQUFpQjs7OztlQUN4Qyx3QkFBQyxNQUFELFlBQUksZUFBZ0I7Ozs7YUFDakI7Ozs7O0tBQ0wsd0JBQUMsUUFBRDtNQUFNLFdBQVcsY0FBYyxlQUFlLFdBQVc7Z0JBQXpELENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsYUFBYzs7OztnQkFDN0IsZUFBZSxrQkFBa0IsaUJBQzlCOzs7Ozs7SUFDQTs7Ozs7O0dBRVIsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkI7S0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBVTtLQUFtQjs7Ozs7S0FDMUMsd0JBQUMsTUFBRCxZQUFJLHVCQUF3Qjs7Ozs7S0FDNUIsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWU7S0FBdUQ7Ozs7O0lBQzVFOzs7Ozs7R0FFVCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtJQUFhLG1CQUFnQjtjQUFoRDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxJQUFHO2lCQUFnQjtNQUFjOzs7O2dCQUNyQyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUFzQixNQUFNO1FBQU87UUFBVTtRQUFlO09BQWE7Ozs7O2NBQ3RFOzs7O2dCQUNMLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUE4QixNQUFNLFNBQVMsZ0JBQWUsT0FBVzs7Ozs7Y0FDcEU7Ozs7OztLQUVMLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQVksVUFBVTtnQkFBdEM7T0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtRQUFVLFNBQVE7a0JBQWE7T0FBaUI7Ozs7O09BQ2pFLHdCQUFDLFNBQUQ7UUFDRSxJQUFHO1FBQ0gsT0FBTztRQUNQLFdBQVcsVUFBVSxTQUFTLE1BQU0sT0FBTyxLQUFLO1FBQ2hELGFBQVk7UUFDWixjQUFhO09BQ2Q7Ozs7O09BQ0Qsd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxXQUFVO2tCQUFhO09BQWtCOzs7OztNQUMzRDs7Ozs7O0tBRUwsU0FBUyx3QkFBQyxLQUFEO01BQUcsTUFBSztNQUFRLFdBQVU7Z0JBQWlCO0tBQVM7Ozs7O0tBRTdELFVBQ0Msd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWM7S0FBc0I7Ozs7Z0JBQy9DLE1BQU0sV0FBVyxJQUNuQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO09BQWEsZUFBWTtpQkFBTztNQUFPOzs7O2dCQUN2RCx3QkFBQyxLQUFELFlBQUcsOENBQThDOzs7O2NBQzlDOzs7OztnQkFFTCx3QkFBQyxNQUFEO01BQUksV0FBVTtNQUFZLGNBQVc7Z0JBQ2xDLE1BQU0sS0FBSyxTQUNWLHdCQUFDLE1BQUQ7T0FBSSxXQUFXLGFBQWEsS0FBSyxjQUFjLGlCQUFpQjtpQkFBaEU7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTtTQUFjLGVBQVk7bUJBQ3ZDLEtBQUssY0FBYyxNQUFNO1FBQ3RCOzs7OztRQUNOLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFjLEtBQUs7UUFBWTs7Ozs7UUFDOUMsS0FBSyxjQUNKLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFrQjtRQUFlOzs7O21CQUVqRCx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7U0FDVixlQUFlLGFBQWEsS0FBSyxFQUFFO1NBQ25DLGNBQVksWUFBWSxLQUFLO21CQUM5QjtRQUVPOzs7OztPQUVSO1NBakJ1RSxLQUFLOzs7O2FBaUI1RSxDQUNMO0tBQ0M7Ozs7O0lBRUM7Ozs7OztHQUVULHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztjQUM1Qix3QkFBQyxRQUFELFlBQU0sZ0NBQW1DOzs7O1lBQ25DOzs7Ozs7RUFDSjs7Ozs7O0FBRVY7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB0eXBlIEZvcm1FdmVudCB9IGZyb20gJ3JlYWN0JztcblxudHlwZSBUYXNrID0ge1xuICBpZDogbnVtYmVyO1xuICB0aXRsZTogc3RyaW5nO1xuICBpc0NvbXBsZXRlZDogYm9vbGVhbjtcbn07XG5cbmNvbnN0IEFQSV9VUkwgPSBpbXBvcnQubWV0YS5lbnYuVklURV9BUElfVVJMID8/ICdodHRwOi8vbG9jYWxob3N0OjUwMDAvYXBpL3Rhc2tzJztcblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbdGFza3MsIHNldFRhc2tzXSA9IHVzZVN0YXRlPFRhc2tbXT4oW10pO1xuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbYXBpQXZhaWxhYmxlLCBzZXRBcGlBdmFpbGFibGVdID0gdXNlU3RhdGUodHJ1ZSk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZFRhc2tzKCkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goQVBJX1VSTCk7XG4gICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKCdDb3VsZCBub3QgbG9hZCB0YXNrcy4nKTtcbiAgICBjb25zdCBkYXRhID0gKGF3YWl0IHJlc3BvbnNlLmpzb24oKSkgYXMgVGFza1tdO1xuICAgIHNldFRhc2tzKGRhdGEpO1xuICAgIHNldEFwaUF2YWlsYWJsZSh0cnVlKTtcbiAgICBzZXRFcnJvcignJyk7XG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvYWRUYXNrcygpXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICBzZXRBcGlBdmFpbGFibGUoZmFsc2UpO1xuICAgICAgICBzZXRFcnJvcignQ2Fubm90IGNvbm5lY3QgdG8gdGhlIEFQSS4gU3RhcnQgdGhlIC5ORVQgYmFja2VuZCBhbmQgdHJ5IGFnYWluLicpO1xuICAgICAgfSlcbiAgICAgIC5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKTtcbiAgfSwgW10pO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGFkZFRhc2soZXZlbnQ6IEZvcm1FdmVudDxIVE1MRm9ybUVsZW1lbnQ+KSB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCBjbGVhblRpdGxlID0gdGl0bGUudHJpbSgpO1xuXG4gICAgaWYgKCFjbGVhblRpdGxlKSB7XG4gICAgICBzZXRFcnJvcignVGl0bGUgaXMgcmVxdWlyZWQuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goQVBJX1VSTCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdGl0bGU6IGNsZWFuVGl0bGUgfSksXG4gICAgICB9KTtcblxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYm9keT8uZXJyb3IgPz8gJ0NvdWxkIG5vdCBjcmVhdGUgdGFzay4nKTtcbiAgICAgIH1cblxuICAgICAgc2V0VGl0bGUoJycpO1xuICAgICAgYXdhaXQgbG9hZFRhc2tzKCk7XG4gICAgfSBjYXRjaCAoY2F1Z2h0KSB7XG4gICAgICBzZXRFcnJvcihjYXVnaHQgaW5zdGFuY2VvZiBFcnJvciA/IGNhdWdodC5tZXNzYWdlIDogJ0NvdWxkIG5vdCBjcmVhdGUgdGFzay4nKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBjb21wbGV0ZVRhc2soaWQ6IG51bWJlcikge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9VUkx9LyR7aWR9L2NvbXBsZXRlYCwgeyBtZXRob2Q6ICdQVVQnIH0pO1xuICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKCdDb3VsZCBub3QgY29tcGxldGUgdGFzay4nKTtcbiAgICAgIGF3YWl0IGxvYWRUYXNrcygpO1xuICAgIH0gY2F0Y2ggKGNhdWdodCkge1xuICAgICAgc2V0RXJyb3IoY2F1Z2h0IGluc3RhbmNlb2YgRXJyb3IgPyBjYXVnaHQubWVzc2FnZSA6ICdDb3VsZCBub3QgY29tcGxldGUgdGFzay4nKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBjb21wbGV0ZWRDb3VudCA9IHRhc2tzLmZpbHRlcigodGFzaykgPT4gdGFzay5pc0NvbXBsZXRlZCkubGVuZ3RoO1xuXG4gIHJldHVybiAoXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiYXBwLXNoZWxsXCI+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInRvcGJhclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyYW5kLW1hcmtcIiBhcmlhLWhpZGRlbj1cInRydWVcIj7inJM8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJleWVicm93XCI+WU9VUiBXT1JLU1BBQ0U8L3A+XG4gICAgICAgICAgPGgxPlRhc2sgTWFuYWdlcjwvaDE+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bjb25uZWN0aW9uICR7YXBpQXZhaWxhYmxlID8gJ29ubGluZScgOiAnb2ZmbGluZSd9YH0+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3RhdHVzLWRvdFwiIC8+XG4gICAgICAgICAge2FwaUF2YWlsYWJsZSA/ICdBUEkgY29ubmVjdGVkJyA6ICdBUEkgdW5hdmFpbGFibGUnfVxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwid2VsY29tZVwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJleWVicm93XCI+TUFLRSBUT0RBWSBDT1VOVDwvcD5cbiAgICAgICAgPGgyPk9uZSB0aGluZyBhdCBhIHRpbWUuPC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwid2VsY29tZS1jb3B5XCI+Q2FwdHVyZSB5b3VyIG5leHQgc3RlcCBhbmQga2VlcCB5b3VyIG1vbWVudHVtIGdvaW5nLjwvcD5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidGFzay1wYW5lbFwiIGFyaWEtbGFiZWxsZWRieT1cInRhc2tzLWhlYWRpbmdcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbC1oZWFkaW5nXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMiBpZD1cInRhc2tzLWhlYWRpbmdcIj5Zb3VyIHRhc2tzPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm11dGVkXCI+e3Rhc2tzLmxlbmd0aH0gdG90YWwgwrcge2NvbXBsZXRlZENvdW50fSBjb21wbGV0ZWQ8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY291bnQtcGlsbFwiPnt0YXNrcy5sZW5ndGggLSBjb21wbGV0ZWRDb3VudH0gbGVmdDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwidGFzay1mb3JtXCIgb25TdWJtaXQ9e2FkZFRhc2t9PlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzci1vbmx5XCIgaHRtbEZvcj1cInRhc2stdGl0bGVcIj5UYXNrIHRpdGxlPC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGlkPVwidGFzay10aXRsZVwiXG4gICAgICAgICAgICB2YWx1ZT17dGl0bGV9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRUaXRsZShldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJXaGF0IG5lZWRzIHRvIGJlIGRvbmU/XCJcbiAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJhZGQtYnV0dG9uXCI+KyBBZGQgdGFzazwvYnV0dG9uPlxuICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAge2Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImVycm9yLW1lc3NhZ2VcIj57ZXJyb3J9PC9wPn1cblxuICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJlbXB0eS1zdGF0ZVwiPkxvYWRpbmcgeW91ciB0YXNrc+KApjwvcD5cbiAgICAgICAgKSA6IHRhc2tzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJlbXB0eS1pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+4pymPC9zcGFuPlxuICAgICAgICAgICAgPHA+Tm8gdGFza3MgeWV0LiBBZGQgb25lIGFib3ZlIHRvIGdldCBzdGFydGVkLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwidGFzay1saXN0XCIgYXJpYS1sYWJlbD1cIlRhc2tzXCI+XG4gICAgICAgICAgICB7dGFza3MubWFwKCh0YXNrKSA9PiAoXG4gICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9e2B0YXNrLWl0ZW0gJHt0YXNrLmlzQ29tcGxldGVkID8gJ2lzLWNvbXBsZXRlZCcgOiAnJ31gfSBrZXk9e3Rhc2suaWR9PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhc2stc3RhdHVzXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICAgICAgICAgICAgICB7dGFzay5pc0NvbXBsZXRlZCA/ICfinJMnIDogJyd9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhc2stdGl0bGVcIj57dGFzay50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAge3Rhc2suaXNDb21wbGV0ZWQgPyAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjb21wbGV0ZWQtbGFiZWxcIj5Db21wbGV0ZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbXBsZXRlLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbXBsZXRlVGFzayh0YXNrLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YENvbXBsZXRlICR7dGFzay50aXRsZX1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBDb21wbGV0ZVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICl9XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiZm9vdGVyXCI+XG4gICAgICAgIDxzcGFuPkJ1aWx0IGZvciBmb2N1cy48L3NwYW4+XG4gICAgICAgIDxzcGFuPlJlYWN0IMK3IFR5cGVTY3JpcHQgwrcgLk5FVCBBUEk8L3NwYW4+XG4gICAgICA8L2Zvb3Rlcj5cbiAgICA8L21haW4+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdfQ==